# Future Spark website

Static site, no build step. `index.html` holds all CSS and JS; the photos and SVGs beside it are referenced relatively, so keep them in the same folder.

## Deploy
- **GitHub Pages:** Settings → Pages → Source: "Deploy from a branch" → `main` / root. The site is live at `https://<owner>.github.io/<repo>/` in about a minute.
- **Netlify / Cloudflare Pages:** point at this repo, no build command, publish directory `/`.

## Before launch
Search `index.html` for `[[PLACEHOLDER` (75 of them). The footer button "Hide placeholder highlights" toggles the yellow marking for previews. `logo-note.md` explains the proposed logo. The full delivery notes (research, grant checklist, placeholder inventory, go-live steps) are in the Claude project.

## Forms
Both forms post to Formspree. Create a form at formspree.io and replace `[[PLACEHOLDER: formspree id]]` in the two `action` attributes. Until then, submitting shows an email fallback instead of failing.

# Future Spark logo — proposal, not final

1. **The mark** is a zip bag / kit box drawn as an open-cornered rounded square, with a four-point spark bursting out of the open corner. It says "kit" first and "spark" second, which is the right order for this org.
2. **Files:** `future-spark-logo.svg` (mark + wordmark, color), `future-spark-logo-mono.svg` (one color, navy), `future-spark-logo-reversed.svg` (paper on navy), `future-spark-mark.svg` (mark alone), `favicon.svg` (mark on a navy rounded square, thicker strokes for 16–32 px).
3. **Colors:** ink navy `#101C33`, spark amber `#E3A73A`. Never amber text; amber is only the spark, the primary button fill, and one rule line.
4. **Wordmark:** Fraunces SemiBold, outlined to paths, so the SVG needs no font installed. Tracking −1%.
5. **Minimum size:** 24 px tall for the lockup, 16 px for the favicon. Below that use the mark alone.
6. **Clear space:** the height of the spark on all sides.
7. **Don'ts:** no gradients (the draft site's mark used one; it disappears at 32 px), no drop shadows, no stretching, no placing on busy photos, no recoloring the spark.
8. **Rejected concepts:** "Trace" (circuit line + node under the wordmark) reads as fintech at small sizes; "FS monogram" falls apart at 32 px because the S loses its shape. The draft site's gold spark-and-swoosh becomes a thin comet at 32 px and fails in one color.
9. **Scoring (out of 5):** reads as hands-on STEM 4 · works at 32 px 5 · works in one color 5 · not a template 4. The one weakness: a generic 4-point spark is common; the open-corner bag is what makes it specific.
10. **Status:** the team should approve or reject this before it goes on anything printed. If Future Spark already has a logo file, use that instead and delete these.
